const socket = io();

/* ── STATE ── */
let MY_ID = localStorage.getItem("caro_pid");
if (!MY_ID) { MY_ID = "p_" + Math.random().toString(36).slice(2, 9); localStorage.setItem("caro_pid", MY_ID); }

const ICONS = [
  "✕","○","△","□","◆","★","✦","⊕",
  "⊗","⊙","◎","◉","◈","⊞","⊟","⊠",
  "♟","♔","♕","♖","♗","♘","♙",
  "✚","✜","✤","✿","❋","❊","❉","❈"
];
function iconCls(ic) {
  if (["✕","⊗","⊠","⊟","✚","✜","✤"].includes(ic)) return "ix";
  if (["○","⊕","⊙","◎","◉","◈","⊞"].includes(ic)) return "io";
  return "";
}

let myIcon = localStorage.getItem("caro_icon") || ICONS[0];
let myName = localStorage.getItem("caro_name") || "";
let lockedIcons = new Set();

let S = { roomId:"", sym:"", icon:"", turn:"", started:false, over:false,
          size:0, winCount:5, dirs:[], maxP:0, bot:false, botDiff:"medium" };

/* ── TOAST ── */
let _tt;
function toast(msg, ms=2400) {
  const t = document.getElementById("toast");
  t.textContent = msg; t.classList.remove("hidden");
  clearTimeout(_tt); _tt = setTimeout(() => t.classList.add("hidden"), ms);
}

/* ── SCREENS ── */
function go(id) {
  document.querySelectorAll(".screen").forEach(s => s.classList.add("hidden"));
  const el = document.getElementById(id); el.classList.remove("hidden");
  void el.offsetWidth;
}

/* ── PILLS ── */
function initPills(gid, hid, cb) {
  const g = document.getElementById(gid); if (!g) return;
  g.querySelectorAll(".pill").forEach(p => p.onclick = () => {
    g.querySelectorAll(".pill").forEach(x => x.classList.remove("on"));
    p.classList.add("on"); document.getElementById(hid).value = p.dataset.val; cb?.();
  });
}
function updateSummary() {
  const bs = document.getElementById("boardSize")?.value || 10;
  const wc = document.getElementById("winCountSelect")?.value || 5;
  const mp = document.getElementById("maxPlayers")?.value;
  const s = (!mp || mp === "0") ? "Không giới hạn" : mp + " người";
  const el = document.getElementById("createSummary"); if (el) el.textContent = `Bàn ${bs}×${bs} · Thắng ${wc} ô · ${s}`;
}

/* ── ICON PICKERS ── */
function buildPicker(cid, showTaken, onPick) {
  const c = document.getElementById(cid); if (!c) return;
  c.innerHTML = "";
  ICONS.forEach(ic => {
    const el = document.createElement("div");
    const cls = iconCls(ic), taken = showTaken && lockedIcons.has(ic);
    el.className = "icon-opt" + (cls ? " " + cls : "") + (ic === myIcon ? " selected" : "") + (taken ? " taken" : "");
    el.textContent = ic; el.title = taken ? "Đã có người dùng" : ic;
    el.onclick = () => {
      if (taken) return;
      myIcon = ic; localStorage.setItem("caro_icon", ic);
      c.querySelectorAll(".icon-opt").forEach(e => e.classList.remove("selected"));
      el.classList.add("selected"); onPick?.(ic);
    };
    c.appendChild(el);
  });
}
function buildBotPicker() {
  buildPicker("botIconPicker", false, ic => {
    const p = document.getElementById("botIconPreview"); if (p) { p.textContent = ic; p.className = iconCls(ic); }
  });
  const p = document.getElementById("botIconPreview"); if (p) { p.textContent = myIcon; p.className = iconCls(myIcon); }
}
function buildLobbyPicker() {
  buildPicker("lobbyIconPicker", true, ic => socket.emit("changeIcon", { roomId: S.roomId, icon: ic }));
}
function syncLocked(players) {
  lockedIcons = new Set(players.filter(p => p.playerId !== MY_ID && p.icon).map(p => p.icon));
  if (lockedIcons.has(myIcon)) {
    const f = ICONS.find(i => !lockedIcons.has(i));
    if (f) { myIcon = f; localStorage.setItem("caro_icon", f); socket.emit("changeIcon", { roomId: S.roomId, icon: f }); }
  }
  buildLobbyPicker();
}

/* ── INIT ── */
window.addEventListener("DOMContentLoaded", () => {
  document.getElementById("profileId").textContent = "ID: " + MY_ID.slice(0, 10);
  const ni = document.getElementById("playerName"); ni.value = myName;
  ni.oninput = () => { myName = ni.value.trim(); localStorage.setItem("caro_name", myName); };
  initPills("pBoardSize", "boardSize", updateSummary);
  initPills("pWinCount", "winCountSelect", updateSummary);
  initPills("pMaxPlayers", "maxPlayers", updateSummary);
  initPills("pBotSize", "botBoardSize");
  initPills("pBotWin", "botWinCount");

  // Theme toggle
  const savedTheme = localStorage.getItem("caro_theme") || "dark";
  applyTheme(savedTheme);
  document.getElementById("btnTheme").onclick = () => {
    const isLight = document.body.classList.contains("light");
    applyTheme(isLight ? "dark" : "light");
  };
  function applyTheme(t) {
    document.body.classList.toggle("light", t === "light");
    document.getElementById("btnTheme").textContent = t === "light" ? "🌙" : "☀️";
    localStorage.setItem("caro_theme", t);
  }

  // ── Validated number input helper ──
  function numInput(inputId, hintId, hiddenId, min, max, pillsSelector, extraCb) {
    const inp = document.getElementById(inputId);
    const hint = document.getElementById(hintId);
    if (!inp) return;
    inp.oninput = () => {
      const raw = inp.value;
      if (raw === "" || raw === null) {
        inp.classList.remove("input-error");
        if (hint) { hint.textContent = ""; hint.className = "input-hint"; }
        return;
      }
      const v = parseInt(raw);
      if (isNaN(v)) {
        inp.classList.add("input-error");
        if (hint) { hint.textContent = "⚠ Vui lòng nhập số hợp lệ"; hint.className = "input-hint err"; }
        return;
      }
      if (v < min) {
        inp.classList.add("input-error");
        if (hint) { hint.textContent = `⚠ Tối thiểu là ${min}`; hint.className = "input-hint err"; }
        return;
      }
      if (v > max) {
        inp.classList.add("input-error");
        if (hint) { hint.textContent = `⚠ Tối đa là ${max} — vui lòng nhập lại`; hint.className = "input-hint err"; }
        // Block: revert to max, keep showing error until user fixes
        return;
      }
      // Valid
      inp.classList.remove("input-error");
      if (hint) { hint.textContent = `✓ Hợp lệ`; hint.className = "input-hint ok"; }
      document.getElementById(hiddenId).value = v;
      document.querySelectorAll(pillsSelector + " .pill").forEach(p => p.classList.remove("on"));
      extraCb?.();
    };
    // Also block keydown if would exceed max
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Backspace" || e.key === "Delete" || e.key === "Tab" ||
          e.key === "ArrowLeft" || e.key === "ArrowRight" || e.key === "ArrowUp" || e.key === "ArrowDown") return;
      const cur = inp.value;
      const hypothetical = parseInt(cur + e.key);
      if (!isNaN(hypothetical) && hypothetical > max) {
        e.preventDefault();
        inp.classList.add("input-error");
        if (hint) { hint.textContent = `⚠ Tối đa là ${max}`; hint.className = "input-hint err"; }
        setTimeout(() => {
          inp.classList.remove("input-error");
          if (hint && hint.textContent.startsWith("⚠ Tối đa")) { hint.textContent = ""; hint.className = "input-hint"; }
        }, 2000);
      }
    });
  }

  // Manual number inputs for create room
  numInput("boardSizeInput",  "hintBoardSize",   "boardSize",      3, 30, "#pBoardSize",   updateSummary);
  numInput("winCountInput",   "hintWinCount",    "winCountSelect", 3, 10, "#pWinCount",    updateSummary);
  numInput("maxPlayersInput", "hintMaxPlayers",  "maxPlayers",     2, 99, "#pMaxPlayers",  updateSummary);

  // Manual number inputs for bot
  numInput("botBoardSizeInput", "hintBotSize", "botBoardSize", 3, 30, "#pBotSize", null);
  numInput("botWinCountInput",  "hintBotWin",  "botWinCount",  3, 10, "#pBotWin",  null);
  updateSummary(); updateStats(); go("screen-menu");
  socket.emit("init", { playerId: MY_ID });
});

/* ── MENU ── */
document.getElementById("btnCreateRoom").onclick = () => go("screen-create");
document.getElementById("btnBrowseRooms").onclick = () => { go("screen-rooms"); socket.emit("getRoomList"); };
document.getElementById("btnPlayBot").onclick = () => { buildBotPicker(); go("screen-bot"); };
document.getElementById("btnBackMenu1").onclick = () => go("screen-menu");
document.getElementById("btnBackMenu2").onclick = () => go("screen-menu");
document.getElementById("btnBackMenu3").onclick = () => go("screen-menu");

/* ── TẠO PHÒNG ── */
document.getElementById("btnConfirmCreate").onclick = () => {
  const boardSize = +document.getElementById("boardSize").value;
  const winCount = +document.getElementById("winCountSelect").value;
  const mpVal = document.getElementById("maxPlayers").value;
  const maxPlayers = (!mpVal || mpVal === "0") ? 999 : +mpVal;
  const dirs = [...document.querySelectorAll('input[name="dir"]:checked')].map(c => c.value);
  if (!dirs.length) { toast("⚠ Chọn ít nhất 1 hướng!"); return; }
  socket.emit("createRoom", { boardSize, winCount, winDirections: dirs, maxPlayers, playerId: MY_ID, icon: myIcon });
};
socket.on("roomCreated", d => {
  Object.assign(S, { roomId: d.roomId, sym: d.symbol, icon: d.icon, size: d.boardSize, winCount: d.winCount, dirs: d.winDirections, maxP: d.maxPlayers });
  enterLobby(d);
});

document.getElementById("btnCopyRoom").onclick = () => {
  navigator.clipboard.writeText(S.roomId).then(() => {
    toast("✅ Đã sao chép mã phòng!");
    const b = document.getElementById("btnCopyRoom"); b.textContent = "✅ Đã sao chép!";
    setTimeout(() => b.textContent = "📋 Sao chép & mời", 2200);
  });
};

/* ── TÌM PHÒNG ── */
socket.on("roomList", renderRooms); socket.on("roomListUpdate", renderRooms);
function renderRooms(rooms) {
  const el = document.getElementById("roomList"); if (!el) return;
  if (!rooms?.length) { el.innerHTML = '<p style="color:var(--dim);text-align:center;padding:18px;font-size:12px;font-style:italic">Chưa có phòng nào</p>'; return; }
  el.innerHTML = rooms.map(r => {
    const mx = r.maxPlayers >= 999 ? "∞" : r.maxPlayers;
    return `<div class="room-item"><div class="ri-info"><b>${r.id}</b><span>${r.boardSize}×${r.boardSize} · ${r.winCount} ô · ${r.currentPlayers}/${mx}</span></div><button class="room-join-btn" onclick="joinRoom('${r.id}')">Vào →</button></div>`;
  }).join("");
}
document.getElementById("btnRefreshRooms").onclick = () => { socket.emit("getRoomList"); toast("↺ Đã làm mới"); };
document.getElementById("btnJoinById").onclick = () => { const id = document.getElementById("joinRoomId").value.trim(); if (id) joinRoom(id); };
function joinRoom(id) { socket.emit("joinRoom", { roomId: id, playerId: MY_ID, icon: myIcon }); }
socket.on("joined", d => {
  Object.assign(S, { roomId: d.roomId, sym: d.symbol, icon: d.icon, size: d.boardSize, winCount: d.winCount, dirs: d.winDirections, maxP: d.maxPlayers });
  enterLobby(d);
});
socket.on("joinFailed", ({ reason }) => toast("❌ " + reason, 3200));

/* ── LOBBY ── */
function enterLobby(d) {
  go("screen-lobby");
  document.getElementById("lobbyRoomId").textContent = d.roomId;
  const mpStr = (!d.maxPlayers || d.maxPlayers >= 999) ? "Không giới hạn" : d.maxPlayers + " người";
  document.getElementById("roomSettingsSummary").innerHTML =
    `${d.boardSize}×${d.boardSize} · Thắng ${d.winCount} ô<br>${mpStr}`;
  syncLocked(d.players); renderLobby(d.players, d.maxPlayers);
  const btn = document.getElementById("btnReady"); btn.disabled = false; btn.textContent = "✅ Sẵn sàng";
  // Ẩn nút bắt đầu ban đầu
  const startBtn = document.getElementById("btnHostStart");
  if (startBtn) startBtn.classList.add("hidden");
}
socket.on("playerJoined", ({ players }) => { syncLocked(players); renderLobby(players, S.maxP); toast("👋 Có người vào phòng!"); });
socket.on("playerReadyUpdate", ({ players, allReady }) => {
  syncLocked(players); renderLobby(players, S.maxP);
  const me = players.find(p => p.playerId === MY_ID);
  if (me?.ready) { const b = document.getElementById("btnReady"); b.disabled = true; b.textContent = "✅ Đã sẵn sàng!"; }
  const rdy = players.filter(p => p.ready).length;
  document.getElementById("lobbyHint").textContent =
    players.length < 2 ? "⏳ Mời bạn vào phòng..." :
    allReady ? "🚀 Tất cả sẵn sàng!" : `${rdy}/${players.length} sẵn sàng`;
  // Hiện nút bắt đầu cho host khi allReady
  const startBtn = document.getElementById("btnHostStart");
  if (startBtn) {
    const isHost = players.length > 0 && players[0].playerId === MY_ID;
    startBtn.classList.toggle("hidden", !(isHost && allReady));
  }
});
socket.on("iconTaken", ({ icon }) => {
  const f = ICONS.find(i => !lockedIcons.has(i) && i !== icon);
  if (f) { myIcon = f; localStorage.setItem("caro_icon", f); buildLobbyPicker(); socket.emit("changeIcon", { roomId: S.roomId, icon: f }); }
  toast("⚠ Icon đã bị dùng, tự đổi sang cái khác");
});
function renderLobby(players, maxP) {
  const c = document.getElementById("lobbyPlayers");
  c.innerHTML = players.map(p => {
    const cls = iconCls(p.icon || p.symbol);
    return `<div class="lp-card ${p.ready ? "ready" : ""}">
      <div class="lp-ico${cls ? " " + cls : ""}">${p.icon || p.symbol}</div>
      <div class="lp-sym">${p.symbol}</div>
      <div class="lp-name">${p.playerId === MY_ID ? "Bạn" : p.playerId.slice(0, 7)}</div>
      <div class="lp-st">${p.ready ? "✅ Sẵn sàng" : "⏳ Chờ"}</div>
    </div>`;
  }).join("") + Array.from(
    { length: Math.min(2, Math.max(0, (maxP >= 999 ? players.length + 1 : maxP) - players.length)) },
    () => '<div class="empty-slot">Chờ...</div>'
  ).join("");
}
document.getElementById("btnReady").onclick = () => socket.emit("playerReady", { roomId: S.roomId });
document.getElementById("btnHostStart").onclick = () => socket.emit("hostStart", { roomId: S.roomId });
document.getElementById("btnLeaveLobby").onclick = () => location.reload();

/* ── BOT SETUP ── */
document.getElementById("btnStartBot").onclick = () => {
  const size = +document.getElementById("botBoardSize").value;
  const wc = +document.getElementById("botWinCount").value;
  const dirs = [...document.querySelectorAll('input[name="botDir"]:checked')].map(c => c.value);
  const diff = document.querySelector('input[name="botDiff"]:checked')?.value || "medium";
  if (!dirs.length) { toast("⚠ Chọn ít nhất 1 hướng!"); return; }
  Object.assign(S, { size, winCount: wc, dirs, sym: "X", icon: myIcon, turn: "X", started: true, over: false, bot: true, botDiff: diff, roomId: "BOT" });
  startGameScreen(null);
  const cls = iconCls(myIcon);
  document.getElementById("playersBar").innerHTML =
    `<div class="p-chip active" id="chip-X"><span class="ci${cls ? " " + cls : ""}">${myIcon}</span> X — Bạn</div>
     <div class="p-chip" id="chip-O"><span class="ci">🤖</span> O — Máy</div>`;
  botBoard = Array(size * size).fill("");
  makeBoard(size); setTurn();
};

/* ── BOT AI ── */
let botBoard = [];
function botMove() {
  if (S.over || S.turn !== "O") return;
  document.getElementById("board").classList.add("board-disabled");
  const delay = S.botDiff === "easy" ? 350 : S.botDiff === "medium" ? 600 : 900;
  setTimeout(() => { const i = pickBot(); if (i !== -1) { botBoard[i] = "O"; placeBotCell(i, "O"); } }, delay);
}
function pickBot() {
  if (S.botDiff === "easy") return randMove();
  const w = findWin("O"); if (w !== -1) return w;
  const b = findWin("X"); if (b !== -1) return b;
  return S.botDiff === "medium" ? stratMove() : hardMove();
}
function randMove() { const e = botBoard.map((v, i) => v === "" ? i : -1).filter(i => i !== -1); return e.length ? e[Math.floor(Math.random() * e.length)] : -1; }
function findWin(sym) { for (let i = 0; i < botBoard.length; i++) { if (botBoard[i] !== "") continue; botBoard[i] = sym; if (winCheck(i, sym)) { botBoard[i] = ""; return i; } botBoard[i] = ""; } return -1; }
function stratMove() {
  const sz = S.size, occ = botBoard.map((v, i) => v !== "" ? i : -1).filter(i => i !== -1);
  if (!occ.length) return Math.floor(botBoard.length / 2);
  let best = -1, bs = -1;
  for (let i = 0; i < botBoard.length; i++) {
    if (botBoard[i] !== "") continue; let sc = 0;
    const r = Math.floor(i / sz), c = i % sz;
    for (const o of occ) { const d = Math.max(Math.abs(Math.floor(o / sz) - r), Math.abs(o % sz - c)); if (d <= 2) sc += (3 - d); }
    botBoard[i] = "O"; sc += chain(i, "O") * 3; botBoard[i] = "X"; sc += chain(i, "X") * 2; botBoard[i] = "";
    if (sc > bs) { bs = sc; best = i; }
  }
  return best !== -1 ? best : randMove();
}
function hardMove() {
  const cands = candidates(); let best = -1, bs = -Infinity;
  for (const i of cands) { if (botBoard[i] !== "") continue; botBoard[i] = "O"; const sc = scoreAll("O") - scoreAll("X") * 1.1; botBoard[i] = ""; if (sc > bs) { bs = sc; best = i; } }
  return best !== -1 ? best : stratMove();
}
function candidates() {
  const sz = S.size, s = new Set();
  for (let i = 0; i < botBoard.length; i++) { if (botBoard[i] === "") continue; const r = Math.floor(i / sz), c = i % sz; for (let dr = -2; dr <= 2; dr++) for (let dc = -2; dc <= 2; dc++) { const nr = r + dr, nc = c + dc; if (nr >= 0 && nr < sz && nc >= 0 && nc < sz && botBoard[nr * sz + nc] === "") s.add(nr * sz + nc); } }
  if (!s.size) s.add(Math.floor(botBoard.length / 2)); return [...s];
}
function scoreAll(sym) { let t = 0; for (let i = 0; i < botBoard.length; i++) if (botBoard[i] === sym) t += chain(i, sym); return t; }
function chain(idx, sym) {
  const sz = S.size, r = Math.floor(idx / sz), c = idx % sz; let mx = 0;
  for (const [dx, dy] of [[1,0],[0,1],[1,1],[1,-1]]) {
    let n = 1;
    for (let d = 1; d < 6; d++) { const nr = r+dy*d, nc = c+dx*d; if (nr<0||nr>=sz||nc<0||nc>=sz||botBoard[nr*sz+nc]!==sym) break; n++; }
    for (let d = 1; d < 6; d++) { const nr = r-dy*d, nc = c-dx*d; if (nr<0||nr>=sz||nc<0||nc>=sz||botBoard[nr*sz+nc]!==sym) break; n++; }
    if (n > mx) mx = n;
  }
  return mx;
}
function winCheck(idx, sym) {
  const sz = S.size, r = Math.floor(idx / sz), c = idx % sz;
  for (const d of [{n:"horizontal",dx:1,dy:0},{n:"vertical",dx:0,dy:1},{n:"diagonal",dx:1,dy:1},{n:"diagonal",dx:1,dy:-1}]) {
    if (!S.dirs.includes(d.n)) continue;
    let cells = [[r,c]], cr = r+d.dy, cc = c+d.dx;
    while (cr>=0&&cr<sz&&cc>=0&&cc<sz&&botBoard[cr*sz+cc]===sym) { cells.push([cr,cc]); cr+=d.dy; cc+=d.dx; }
    cr = r-d.dy; cc = c-d.dx;
    while (cr>=0&&cr<sz&&cc>=0&&cc<sz&&botBoard[cr*sz+cc]===sym) { cells.push([cr,cc]); cr-=d.dy; cc-=d.dx; }
    if (cells.length >= S.winCount) return cells;
  }
  return null;
}
function placeBotCell(idx, sym) {
  const board = document.getElementById("board"), cell = board.children[idx]; if (!cell) return;
  cell.textContent = sym === "O" ? "🤖" : (S.icon || "✕");
  cell.dataset.taken = "1"; cell.classList.remove("x-cell","o-cell");
  cell.classList.add(sym === "X" ? "x-cell" : "o-cell");
  board.querySelectorAll(".last-move").forEach(c => c.classList.remove("last-move"));
  cell.classList.add("last-move");
  const wc = winCheck(idx, sym);
  if (wc) {
    wc.forEach(([row,col]) => board.children[row*S.size+col]?.classList.add("win"));
    S.over = true; S.started = false; board.classList.remove("board-disabled");
    const win = sym === "X";
    document.getElementById("popupEmoji").textContent = win ? "🎉" : "😢";
    if (win) confetti();
    showResult(win ? "Bạn thắng!" : "Máy thắng!", win ? "Xuất sắc! 🏆" : "Thử lại nào! 💪");
    addStat(win ? "win" : "lose"); return;
  }
  if (botBoard.every(c => c !== "")) {
    S.over = true; S.started = false; board.classList.remove("board-disabled");
    document.getElementById("popupEmoji").textContent = "🤝";
    showResult("Hòa rồi!", "Không ai thắng"); addStat("draw"); return;
  }
  S.turn = sym === "X" ? "O" : "X"; updateChips(S.turn); setTurn();
  if (S.turn === "O") botMove(); else board.classList.remove("board-disabled");
}

/* ── HINT ── */
function doHint() {
  if (!S.bot || !S.started || S.over || S.turn !== "X") { toast("💡 Chỉ dùng được khi tới lượt bạn"); return; }
  clearHints();
  let h = findWin("X"); if (h === -1) h = findWin("O"); if (h === -1) h = stratMove();
  if (h !== -1) {
    const cell = document.getElementById("board").children[h];
    if (cell && !cell.dataset.taken) {
      cell.classList.add("hint-cell"); toast("💡 Ô sáng = gợi ý tốt nhất");
      setTimeout(() => cell.classList.remove("hint-cell"), 2800);
    }
  }
}
function clearHints() { document.querySelectorAll(".hint-cell").forEach(c => c.classList.remove("hint-cell")); }

/* ── CONFETTI ── */
function confetti() {
  const c = document.getElementById("popupConfetti"); if (!c) return; c.innerHTML = "";
  const cols = ["#c8992a","#e0b040","#4a9652","#c84040","#4a7ab8","#b8a060"];
  for (let i = 0; i < 20; i++) {
    const d = document.createElement("div"); d.className = "c-dot";
    const sz = Math.random() * 7 + 4;
    d.style.cssText = `width:${sz}px;height:${sz}px;left:${Math.random()*100}%;top:${Math.random()*15}%;background:${cols[~~(Math.random()*cols.length)]};animation-delay:${Math.random()*.5}s;animation-duration:${1+Math.random()}s`;
    c.appendChild(d);
  }
}

/* ── GAME START (multi) ── */
socket.on("gameStart", ({ turn, time, players }) => {
  Object.assign(S, { started: true, over: false, turn, bot: false });
  startGameScreen(players);
  document.getElementById("timerDisplay").textContent = time;
  renderChips(players, turn); makeBoard(S.size); setTurn(); clearChat();
  addSysMsg("🎯 Ván đấu bắt đầu!");
});

/* ── BUILD GAME LAYOUT ── */
function startGameScreen(players) {
  go("screen-game");
  document.getElementById("roomDisplay").textContent = S.bot ? "🤖 vs Máy" : "🏠 " + S.roomId;
  const gl = document.getElementById("gameLayout");
  if (S.bot) {
    // Bot: bàn cờ + actions bên dưới, KHÔNG có chat
    gl.className = "game-layout-bot";
    gl.innerHTML = `
      <div class="board-side">
        <div class="board-outer"><div id="board" class="board-grid"></div></div>
        <div class="in-game-acts" id="inGameActs">
          <button class="act-btn hint-btn" id="btnHint">💡 Gợi ý</button>
          <button class="act-btn exit-btn" id="btnExitGame">✕ Thoát</button>
        </div>
        <div class="game-acts hidden" id="actions">
          <button class="btn-ghost" id="restartBtn">↺ Chơi lại</button>
          <button class="btn-danger" id="leaveBtn">✕ Thoát</button>
        </div>
      </div>`;
    document.getElementById("btnHint").onclick = doHint;
    document.getElementById("btnExitGame").onclick = () => { if (confirm("Thoát ván đấu?")) location.reload(); };
    document.getElementById("restartBtn").onclick = restart;
    document.getElementById("leaveBtn").onclick = () => location.reload();
    document.getElementById("drawPopup").classList.add("hidden");
  } else {
    // Online: bàn cờ + chat cạnh nhau
    gl.className = "game-layout-online";
    gl.innerHTML = `
      <div class="board-side">
        <div class="board-outer"><div id="board" class="board-grid"></div></div>
        <div class="in-game-acts" id="inGameActs">
          <button class="act-btn draw-btn" id="btnDraw">🤝 Xin hòa</button>
          <button class="act-btn surr-btn" id="btnSurrender">🏳 Đầu hàng</button>
          <button class="act-btn exit-btn" id="btnExitGame">✕ Thoát</button>
        </div>
        <div class="game-acts hidden" id="actions">
          <button class="btn-ghost" id="restartBtn">↺ Chơi lại</button>
          <button class="btn-danger" id="leaveBtn">✕ Thoát</button>
        </div>
      </div>
      <div class="chat-side" id="chatSide">
        <div class="chat-head">Chat</div>
        <div class="chat-msgs" id="chatMsgs"></div>
        <div class="chat-reacts">
          <button class="react-btn" data-msg="👍">👍</button>
          <button class="react-btn" data-msg="😂">😂</button>
          <button class="react-btn" data-msg="🔥">🔥</button>
          <button class="react-btn" data-msg="😱">😱</button>
          <button class="react-btn" data-msg="GG! 🏆">🏆</button>
        </div>
        <div class="chat-row">
          <input type="text" id="chatInput" class="chat-inp" placeholder="Nhắn gì đó..." maxlength="80"/>
          <button class="chat-send" id="chatSend">↑</button>
        </div>
      </div>`;
    document.getElementById("btnDraw").onclick = () => { if (!S.started || S.over) return; if (confirm("Xin hòa?")) socket.emit("drawRequest", { roomId: S.roomId }); };
    document.getElementById("btnSurrender").onclick = () => { if (!S.started || S.over) return; if (confirm("Đầu hàng?")) socket.emit("surrender", { roomId: S.roomId }); };
    document.getElementById("btnExitGame").onclick = () => { if (confirm("Thoát ván đấu?")) location.reload(); };
    document.getElementById("restartBtn").onclick = restart;
    document.getElementById("leaveBtn").onclick = () => location.reload();
    document.getElementById("chatSend").onclick = sendChat;
    document.getElementById("chatInput").onkeydown = e => { if (e.key === "Enter") sendChat(); };
    document.querySelectorAll(".react-btn").forEach(b => b.onclick = () => { if (S.roomId) socket.emit("chatMsg", { roomId: S.roomId, text: b.dataset.msg }); });
  }
}

function renderChips(players, cur) {
  document.getElementById("playersBar").innerHTML = players.map(p => {
    const cls = iconCls(p.icon || p.symbol);
    return `<div class="p-chip ${p.symbol === cur ? "active" : ""}" id="chip-${p.symbol}">
      <span class="ci${cls ? " " + cls : ""}">${p.icon || p.symbol}</span> ${p.symbol}${p.playerId === MY_ID ? " — Bạn" : ""}
    </div>`;
  }).join("");
}
function updateChips(t) { document.querySelectorAll(".p-chip").forEach(c => c.classList.remove("active")); document.getElementById("chip-" + t)?.classList.add("active"); }

/* ── BOARD ── */
function makeBoard(sz) {
  const board = document.getElementById("board"); board.innerHTML = "";
  const cs = sz >= 20 ? 26 : sz >= 15 ? 32 : sz >= 10 ? 40 : 50;
  board.style.gridTemplateColumns = `repeat(${sz},${cs}px)`;
  board.style.width = (cs * sz) + "px";
  const f = document.createDocumentFragment();
  for (let i = 0; i < sz * sz; i++) {
    const cell = document.createElement("div");
    cell.className = "cell"; cell.style.cssText = `width:${cs}px;height:${cs}px;font-size:${cs*.48}px`;
    cell.onclick = () => cellClick(cell, i); f.appendChild(cell);
  }
  board.appendChild(f);
}
function cellClick(cell, idx) {
  if (!S.started || S.over || cell.dataset.taken) return;
  clearHints();
  if (S.bot) {
    if (S.turn !== "X") return;
    botBoard[idx] = "X"; placeBotCell(idx, "X");
  } else {
    if (S.turn !== S.sym) return;
    const board = document.getElementById("board"); board.classList.add("board-disabled");
    let ack = false;
    const fb = setTimeout(() => { if (!ack && !S.over && S.turn === S.sym) board.classList.remove("board-disabled"); }, 3000);
    socket.once("moveMade", () => { ack = true; clearTimeout(fb); });
    socket.emit("makeMove", { roomId: S.roomId, index: idx });
  }
}
socket.on("moveMade", ({ index, symbol, icon, turn, timeLeft, win, winCells }) => {
  const board = document.getElementById("board"), cell = board.children[index]; if (!cell) return;
  cell.textContent = icon || symbol; cell.dataset.taken = "1";
  cell.classList.remove("x-cell","o-cell"); cell.classList.add(symbol === "X" ? "x-cell" : "o-cell");
  board.querySelectorAll(".last-move").forEach(c => c.classList.remove("last-move")); cell.classList.add("last-move");
  S.turn = turn; setTurn(); updateChips(turn);
  const td = document.getElementById("timerDisplay"); td.textContent = timeLeft; td.className = "gb-timer" + (timeLeft <= 5 ? " low" : "");
  if (win && winCells) winCells.forEach(i => board.children[i]?.classList.add("win"));
});
socket.on("timerUpdate", ({ timeLeft }) => {
  const td = document.getElementById("timerDisplay"); td.textContent = timeLeft; td.className = "gb-timer" + (timeLeft <= 5 ? " low" : "");
});

/* ── CHAT ── */
function clearChat() { const el = document.getElementById("chatMsgs"); if (el) el.innerHTML = ""; }
function addSysMsg(text) {
  const el = document.getElementById("chatMsgs"); if (!el) return;
  const d = document.createElement("div"); d.className = "chat-msg sys"; d.textContent = text;
  el.appendChild(d); el.scrollTop = el.scrollHeight;
}
function addChatMsg(icon, sym, text, isMe) {
  const el = document.getElementById("chatMsgs"); if (!el) return;
  const d = document.createElement("div"); d.className = "chat-msg";
  d.innerHTML = `<div class="cm-who">${icon || sym} ${sym}${isMe ? " (bạn)" : ""}</div><div class="cm-text">${esc(text)}</div>`;
  el.appendChild(d); el.scrollTop = el.scrollHeight;
}
function esc(t) { return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
function sendChat() {
  const inp = document.getElementById("chatInput"); if (!inp) return;
  const text = inp.value.trim(); if (!text) return;
  socket.emit("chatMsg", { roomId: S.roomId, text }); inp.value = "";
}
socket.on("chatMsg", ({ symbol, icon, text }) => { addChatMsg(icon, symbol, text, symbol === S.sym); });

/* ── XIN HÒA / ĐẦU HÀNG popups ── */
socket.on("drawRequest", ({ fromSymbol, fromIcon }) => {
  document.getElementById("drawFromText").textContent = `${fromIcon || fromSymbol} (${fromSymbol}) xin hòa. Đồng ý?`;
  document.getElementById("drawPopup").classList.remove("hidden");
});
document.getElementById("btnAcceptDraw").onclick = () => { document.getElementById("drawPopup").classList.add("hidden"); socket.emit("drawResponse", { roomId: S.roomId, accept: true }); };
document.getElementById("btnDeclineDraw").onclick = () => { document.getElementById("drawPopup").classList.add("hidden"); socket.emit("drawResponse", { roomId: S.roomId, accept: false }); };
socket.on("drawDeclined", () => { addSysMsg("❌ Đối thủ từ chối hòa."); toast("❌ Bị từ chối"); });

/* ── GAME OVER ── */
socket.on("gameOver", ({ winner, reason, loser }) => {
  S.over = true; S.started = false;
  document.getElementById("board")?.classList.remove("board-disabled");
  document.getElementById("drawPopup").classList.add("hidden");
  let emoji = "", title = "", detail = "";
  if (reason === "draw") { emoji = "🤝"; title = "Hòa!"; detail = "Hai bên đồng ý hòa"; }
  else if (reason === "surrender" && loser === S.sym) { emoji = "🏳"; title = "Đầu hàng"; detail = "Thử lại lần sau!"; }
  else if (reason === "surrender" && winner === S.sym) { emoji = "🎉"; title = "Bạn thắng!"; detail = "Đối thủ đầu hàng!"; confetti(); }
  else if (winner === S.sym) { emoji = "🎉"; title = "Bạn thắng!"; detail = reason === "timeout" ? "Đối thủ hết giờ" : reason === "disconnect" ? "Đối thủ bỏ cuộc" : "Xuất sắc!"; confetti(); }
  else { emoji = "😢"; title = "Bạn thua!"; detail = reason === "timeout" ? "Hết giờ!" : reason === "disconnect" ? "Đối thủ bỏ cuộc" : "Thử lại nào!"; }
  document.getElementById("popupEmoji").textContent = emoji;
  const s = getStats();
  if (reason === "draw") s.draw++; else if (winner === S.sym) s.win++; else if (loser === S.sym || winner) s.lose++;
  const total = s.win + s.lose + s.draw, wr = total ? Math.round(s.win / total * 100) : 0;
  document.getElementById("resultStats").innerHTML =
    `<div class="rs-it"><span class="rs-n">${s.win}</span><span class="rs-l">Thắng</span></div>
     <div class="rs-it"><span class="rs-n">${s.draw}</span><span class="rs-l">Hòa</span></div>
     <div class="rs-it"><span class="rs-n">${s.lose}</span><span class="rs-l">Thua</span></div>
     <div class="rs-it"><span class="rs-n">${wr}%</span><span class="rs-l">Tỉ lệ</span></div>`;
  showResult(title, detail);
  socket.emit("gameOverHandled", { roomId: S.roomId, winner, reason });
  if (reason === "draw") addStat("draw"); else if (winner === S.sym) addStat("win"); else if (loser === S.sym || winner) addStat("lose");
});

/* ── TURN ── */
function setTurn() {
  const td = document.getElementById("turnDisplay"), board = document.getElementById("board");
  if (!td || !board) return;
  if (S.over || !S.started) { board.classList.remove("board-disabled"); td.className = "gb-turn"; return; }
  if (S.bot) {
    if (S.turn === "X") { td.textContent = "Lượt của bạn"; td.className = "gb-turn my"; board.classList.remove("board-disabled"); }
    else { td.textContent = "Máy đang nghĩ..."; td.className = "gb-turn"; board.classList.add("board-disabled"); }
  } else {
    const mine = S.turn === S.sym;
    td.textContent = mine ? "Tới lượt bạn!" : "Đối thủ đang đánh...";
    td.className = "gb-turn" + (mine ? " my" : "");
    mine ? board.classList.remove("board-disabled") : board.classList.add("board-disabled");
  }
}

/* ── RESULT ── */
function showResult(title, detail) {
  document.getElementById("resultTitle").textContent = title;
  document.getElementById("resultReason").textContent = detail;
  document.getElementById("resultPopup").classList.remove("hidden");
  document.getElementById("actions")?.classList.remove("hidden");
}
function restart() {
  document.getElementById("resultPopup").classList.add("hidden");
  document.getElementById("popupConfetti").innerHTML = "";
  if (S.bot) {
    S.turn = "X"; S.started = true; S.over = false;
    botBoard = Array(S.size * S.size).fill(""); makeBoard(S.size);
    document.getElementById("actions")?.classList.add("hidden");
    updateChips("X"); setTurn(); toast("↺ Ván mới!");
  } else {
    S.started = false; S.over = false; S.turn = "";
    // Reset ready state trên server
    socket.emit("resetReady", { roomId: S.roomId });
    go("screen-lobby");
    const b = document.getElementById("btnReady"); b.disabled = false; b.textContent = "✅ Sẵn sàng";
    const startBtn = document.getElementById("btnHostStart");
    if (startBtn) startBtn.classList.add("hidden");
  }
}
document.getElementById("popupRestart").onclick = restart;
document.getElementById("popupLeave").onclick = () => location.reload();

/* ── RECONNECT ── */
socket.on("reconnectSuccess", ({ board, turn, timeLeft, yourSymbol, yourIcon, started, gameOver, boardSize, winCount, winDirections, maxPlayers, players }) => {
  Object.assign(S, { sym: yourSymbol, icon: yourIcon, turn, started: started && !gameOver, over: gameOver, size: boardSize, winCount, dirs: winDirections, maxP: maxPlayers });
  startGameScreen(players); document.getElementById("roomDisplay").textContent = "🏠 " + S.roomId;
  renderChips(players, turn); makeBoard(boardSize);
  const boardEl = document.getElementById("board");
  board.forEach((sym, i) => { if (sym) { const p = players.find(pl => pl.symbol === sym); const cell = boardEl.children[i]; cell.textContent = p?.icon || sym; cell.dataset.taken = "1"; cell.classList.add(sym === "X" ? "x-cell" : "o-cell"); } });
  document.getElementById("timerDisplay").textContent = timeLeft; setTurn(); toast("↩ Đã kết nối lại!");
});
socket.on("playerReconnected", () => { addSysMsg("↩ Đối thủ quay lại!"); setTimeout(setTurn, 1500); });
socket.on("reconnectFailed", () => { toast("❌ Mất kết nối!", 3000); setTimeout(() => location.reload(), 3000); });

/* ── STATS ── */
function getStats() { return JSON.parse(localStorage.getItem("caro_stats")) || { win: 0, lose: 0, draw: 0 }; }
function addStat(t) { const s = getStats(); s[t]++; localStorage.setItem("caro_stats", JSON.stringify(s)); updateStats(); }
function updateStats() {
  const s = getStats();
  document.getElementById("statWin").textContent = s.win;
  document.getElementById("statLose").textContent = s.lose;
  document.getElementById("statDraw").textContent = s.draw;
  document.getElementById("pbWin").textContent = s.win;
  document.getElementById("pbDraw").textContent = s.draw;
  document.getElementById("pbLose").textContent = s.lose;
  const total = s.win + s.lose + s.draw;
  const b = document.getElementById("winRateBadge");
  if (b) b.textContent = total ? Math.round(s.win / total * 100) + "%" : "—";
}
