const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const RoomManager = require("./game/RoomManager");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
const roomManager = new RoomManager();

app.use(express.static(path.join(__dirname, "../Client")));

io.on("connection", (socket) => {
  console.log("Connected:", socket.id);

  socket.on("init", ({ playerId } = {}) => {
    socket.playerId = playerId || socket.id;
  });

  // HOST TẠO PHÒNG
  socket.on("createRoom", ({ boardSize, winCount, winDirections, maxPlayers, playerId, icon } = {}) => {
    const size = parseInt(boardSize);
    if (!size || size < 3 || size > 30) return;
    socket.playerId = playerId || socket.playerId || socket.id;
    roomManager.removePlayer(socket);
    const room = roomManager.createRoom({ boardSize: size, winCount, winDirections, maxPlayers });
    room.attachIO(io);
    room.addPlayer(socket, socket.playerId, icon);
    roomManager.addPlayerToRoom(socket, room);
    socket.emit("roomCreated", {
      roomId: room.id, symbol: socket.symbol, icon: socket.icon,
      boardSize: room.boardSize, winCount: room.winCount,
      winDirections: room.winDirections, maxPlayers: room.maxPlayers,
      players: room.getPlayersInfo(),
      stats: roomManager.getStats(socket.playerId),
    });
    // Thông báo phòng mới cho tất cả
    io.emit("roomListUpdate", roomManager.getPublicRooms());
  });

  // VÀO PHÒNG
  socket.on("joinRoom", ({ roomId, playerId, icon } = {}) => {
    if (typeof roomId !== "string" || !playerId) return;
    socket.playerId = playerId;
    const room = roomManager.getRoom(roomId);
    if (!room) { socket.emit("joinFailed", { reason: "Phòng không tồn tại!" }); return; }
    if (room.isFull()) { socket.emit("joinFailed", { reason: "Phòng đã đầy!" }); return; }
    if (room.started) { socket.emit("joinFailed", { reason: "Ván đấu đã bắt đầu!" }); return; }
    roomManager.removePlayer(socket);
    room.addPlayer(socket, playerId, icon);
    roomManager.addPlayerToRoom(socket, room);

    const joinedData = {
      roomId: room.id, symbol: socket.symbol, icon: socket.icon,
      boardSize: room.boardSize, winCount: room.winCount,
      winDirections: room.winDirections, maxPlayers: room.maxPlayers,
      waiting: true, currentTurn: room.turn, started: false,
      players: room.getPlayersInfo(), stats: roomManager.getStats(socket.playerId),
    };

    // Gửi cho người vừa vào
    socket.emit("joined", joinedData);

    // Thông báo cho TẤT CẢ người trong phòng (kể cả người mới) biết có người join
    // Dùng setImmediate để đảm bảo socket đã join room channel xong
    setImmediate(() => {
      io.to(room.id).emit("playerJoined", { players: room.getPlayersInfo() });
      io.emit("roomListUpdate", roomManager.getPublicRooms());
    });
  });

  // ĐỔI ICON (trong lobby, trước khi bắt đầu)
  socket.on("changeIcon", ({ roomId, icon } = {}) => {
    if (!roomId || !icon) return;
    const room = roomManager.getRoom(roomId);
    if (!room || room.started) return;
    const player = room.players.find(p => p.playerId === socket.playerId);
    if (!player) return;
    // Kiểm tra icon chưa bị dùng
    const taken = room.players.some(p => p.playerId !== socket.playerId && p.icon === icon);
    if (taken) { socket.emit("iconTaken", { icon }); return; }
    player.icon = icon;
    socket.icon = icon;
    io.to(roomId).emit("playerJoined", { players: room.getPlayersInfo() });
  });

  // RESET SẴN SÀNG (sau khi ván xong, chơi lại)
  socket.on("resetReady", ({ roomId } = {}) => {
    if (typeof roomId !== "string") return;
    const room = roomManager.getRoom(roomId);
    if (!room) return;
    room.reset();
    io.to(roomId).emit("playerReadyUpdate", { players: room.getPlayersInfo(), allReady: false });
    io.emit("roomListUpdate", roomManager.getPublicRooms());
  });

  // BẮT ĐẦU (chỉ host)
  socket.on("hostStart", ({ roomId } = {}) => {
    if (typeof roomId !== "string") return;
    const room = roomManager.getRoom(roomId);
    if (!room) return;
    room.hostStart(socket, io);
    io.emit("roomListUpdate", roomManager.getPublicRooms());
  });

  // SẴN SÀNG
  socket.on("playerReady", ({ roomId } = {}) => {
    if (typeof roomId !== "string") return;
    const room = roomManager.getRoom(roomId);
    if (!room) return;
    room.setReady(socket, io);
    io.emit("roomListUpdate", roomManager.getPublicRooms());
  });

  // CHAT
  socket.on("chatMsg", ({ roomId, text } = {}) => {
    if (!roomId || !text || typeof text !== "string") return;
    const room = roomManager.getRoom(roomId);
    if (!room) return;
    const player = room.players.find(p => p.playerId === socket.playerId);
    if (!player) return;
    const msg = { symbol: player.symbol, icon: player.icon, text: text.slice(0, 100), time: Date.now() };
    io.to(roomId).emit("chatMsg", msg);
  });

  // XIN HÒA
  socket.on("drawRequest", ({ roomId } = {}) => {
    if (!roomId) return;
    const room = roomManager.getRoom(roomId);
    if (!room || !room.started || room.gameOver) return;
    const player = room.players.find(p => p.playerId === socket.playerId);
    if (!player) return;
    // Gửi yêu cầu hòa cho tất cả người còn lại
    socket.to(roomId).emit("drawRequest", { fromSymbol: player.symbol, fromIcon: player.icon });
  });

  socket.on("drawResponse", ({ roomId, accept } = {}) => {
    if (!roomId) return;
    const room = roomManager.getRoom(roomId);
    if (!room || !room.started) return;
    if (accept) {
      room.gameOver = true;
      room.stopTimer && room.stopTimer();
      io.to(roomId).emit("gameOver", { winner: null, reason: "draw", loser: null });
    } else {
      socket.to(roomId).emit("drawDeclined");
    }
  });

  // ĐẦU HÀNG
  socket.on("surrender", ({ roomId } = {}) => {
    if (!roomId) return;
    const room = roomManager.getRoom(roomId);
    if (!room || !room.started || room.gameOver) return;
    const loser = room.players.find(p => p.playerId === socket.playerId);
    if (!loser) return;
    const winner = room.players.find(p => p.playerId !== socket.playerId);
    room.gameOver = true;
    room.stopTimer && room.stopTimer();
    io.to(roomId).emit("gameOver", { winner: winner?.symbol || null, reason: "surrender", loser: loser.symbol });
  });

  // ĐI QUÂN
  socket.on("makeMove", ({ roomId, index } = {}) => {
    if (typeof roomId !== "string") return;
    const room = roomManager.getRoom(roomId);
    if (!room) return;
    const result = room.makeMove(socket, index);
    if (!result) return;
    io.to(roomId).emit("moveMade", result);
  });

  socket.on("gameOverHandled", ({ roomId, winner, reason } = {}) => {
    if (typeof roomId !== "string") return;
    const room = roomManager.getRoom(roomId);
    if (!room || room.statsUpdated) return;
    room.statsUpdated = true;
    if (reason === "win") room.players.forEach(p => roomManager.updateStats(p.playerId, p.symbol === winner ? "win" : "lose"));
    if (reason === "draw") room.players.forEach(p => roomManager.updateStats(p.playerId, "draw"));
  });

  socket.on("reconnectToRoom", ({ roomId, playerId } = {}) => {
    if (typeof roomId !== "string" || !playerId) { socket.emit("reconnectFailed", { reason: "invalid" }); return; }
    socket.playerId = playerId;
    socket.reconnecting = true;
    const room = roomManager.getRoom(roomId);
    if (!room) { socket.emit("reconnectFailed", { reason: "room_not_found" }); return; }
    const success = room.addPlayer(socket, playerId);
    if (success) { roomManager.addPlayerToRoom(socket, room); socket.join(room.id); }
    else socket.emit("reconnectFailed", { reason: "cannot_rejoin" });
  });

  socket.on("getRoomList", () => {
    socket.emit("roomList", roomManager.getPublicRooms());
  });

  socket.on("disconnect", () => {
    console.log("Disconnected:", socket.id);
    roomManager.removePlayer(socket);
    io.emit("roomListUpdate", roomManager.getPublicRooms());
  });
});

server.listen(8386, () => console.log("Server running at http://localhost:8386"));
process.on("SIGINT", () => { roomManager.destroy(); server.close(() => process.exit(0)); });
process.on("SIGTERM", () => { roomManager.destroy(); server.close(() => process.exit(0)); });
